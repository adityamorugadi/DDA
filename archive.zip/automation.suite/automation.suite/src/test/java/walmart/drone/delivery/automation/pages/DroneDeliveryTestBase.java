package walmart.drone.delivery.automation.pages;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import walmart.drone.delivery.automation.TestBase;




@Test
public class DroneDeliveryTestBase extends TestBase {

	 public String dataQuery,loginId,labId ="";
	 private static Object lock = new Object();
	 static boolean testDataStatus = false;
 
	/**
	 * Runs before all tests in this class
	 * 
	 * @throws Exception
	 */
	@BeforeClass(alwaysRun = true, inheritGroups = true)
	public void setUpBeforeClass() throws Exception {
		System.out.println("Inside setUpBeforeClass method");
	}
	
	@BeforeMethod(inheritGroups = true)	   
	public void beforeMethod() {
		System.out.println("Inside beforeMethod method");
	}

}