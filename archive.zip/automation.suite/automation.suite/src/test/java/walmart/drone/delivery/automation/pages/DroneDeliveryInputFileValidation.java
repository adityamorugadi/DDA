package walmart.drone.delivery.automation.pages;


import org.testng.annotations.Test;

import walmart.drone.delivery.automation.CommonJavaUtilsHelper;
import walmart.drone.delivery.automation.CommonVariables;


@Test(priority=5)
public class DroneDeliveryInputFileValidation extends DroneDeliveryTestBase {

	
	@Test(enabled=true,description="Verify order detail format provided in input File",groups={"Regression"})
	public void VerifyOrderDetailFormatProvidedInInputFile(){
		CommonVariables.CurrentTestCaseLog.get().info("VerifyOrderDetailFormatProvidedInInputFile");
		CommonVariables.CurrentTestCaseLog.get().info("====================Test Case Steps - Execution Starts=========================");

		(new CommonJavaUtilsHelper()).writeAppendDataInFile("","");
		CommonVariables.CurrentTestCaseLog.get().info("====================Test Case Execution completed========================");
	}

	/**
	 * Disable this method because no need to verify entry at LOG level from Selenium script. Log keep on growing (heavy file) and 
	 * we are not the person who access this environment. RDC flow is already covered in another script.
	 */
	@Test(enabled=true,description="Validate error message when order detail is not in correct format.",groups={"Regression"})
	public void TCOE_ValidateErrorMsgWhenOrderDetailInIncorrectFormat(){

		CommonVariables.CurrentTestCaseLog.get().info("TCOE_ValidateErrorMsgWhenOrderDetailInIncorrectFormat");
		CommonVariables.CurrentTestCaseLog.get().info("====================Test Case Steps - Execution Starts=========================");
		CommonVariables.CurrentTestCaseLog.get().info("====================Test Case Execution completed========================");
	}

}