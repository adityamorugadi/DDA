package walmart.drone.delivery.automation.pages;


import org.testng.annotations.Test;
import walmart.drone.delivery.automation.CommonVariables;


@Test(priority=5)
public class DroneDeliveryOuputFileValidation extends DroneDeliveryTestBase {

	
	@Test(description="Verify when output file is in correct format.",groups={"Regression"})
	public void TC01_VerifyOutputFileisInCorrectFormat(){
		CommonVariables.CurrentTestCaseLog.get().info("TC01_VerifyOutputFileisInCorrectFormat");
		CommonVariables.CurrentTestCaseLog.get().info("====================Test Case Steps - Execution Starts=========================");
		CommonVariables.CurrentTestCaseLog.get().info("====================Test Case Execution completed========================");
	}

	/**
	 * Disable this method because no need to verify entry at LOG level from Selenium script. Log keep on growing (heavy file) and 
	 * we are not the person who access this environment. RDC flow is already covered in another script.
	 */
	@Test(description="Validate when output file does not have NPS value.",groups={"Regression"})
	public void TCO2_ValidateWhenOutputFileDoesNothaveNPS(){

		CommonVariables.CurrentTestCaseLog.get().info("TCO2_ValidateWhenOutputFileDoesNothaveNPS");
		CommonVariables.CurrentTestCaseLog.get().info("====================Test Case Steps - Execution Starts=========================");
		CommonVariables.CurrentTestCaseLog.get().info("====================Test Case Execution completed========================");
	}

}