package walmart.drone.delivery.automation;

public enum LogName {
    CurrentTestClassLog, CurrentGlobalLog, CurrentTestCaseLog, CurrentSiteCoreLog
}
