/**
 *
 */
package walmart.drone.delivery.automation;

import org.apache.logging.log4j.LogManager;
import org.testng.ISuite;
import org.testng.ISuiteListener;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Aditya
 */
public class TestNGStarterFinishListener implements ISuiteListener {
    public static String testType = "";//"smoke";
    public static ArrayList<String> moduleNeedToRun = new ArrayList<String>();//(Arrays.asList("Module2", "Module1"));
    public static ArrayList<String> moduleNoNeedToRun = new ArrayList<String>();
    public static int threadCount = 1;

    @Override
    public void onFinish(ISuite arg0) {
        try {/*
			File dest=new File(System.getProperty("user.dir") +"/test-output-BackUp");
			File src=new File(System.getProperty("user.dir") +"/test-output");
			if(!dest.exists()){
				dest.mkdir();
			}
			else{
				String fileList[] = dest.list();
				if(fileList.length != 0)
				{
					int size = fileList.length;
					for(int i = 0 ; i < size ; i++)
					{
						try{
							String fileName = fileList[i];
							String fullPath = dest.getPath()+"/"+fileName;
							File fileOrFolder = new File(fullPath);
							fileOrFolder.delete();
						}
						catch(Exception ex){}
					}
				}
			}
			String files[] = src.list();

			for (String file : files) {
				File srcFile = new File(src, file);
				File destFile = new File(dest, file);
				CommonJavaUtilsHelper.staticCopyFile(srcFile,destFile);
				InputStream in = new FileInputStream(srcFile);
				OutputStream out = new FileOutputStream(destFile); 
				byte[] buffer = new byte[1024];
				int length;
				while ((length = in.read(buffer)) > 0){
					out.write(buffer, 0, length);
				}
				in.close();
				out.close();
			}
		*/
        } catch (Exception e1) {
        }

    }

    @Override
    public void onStart(ISuite testSuite) {
        try {
            LogManager.getLogger("org.apache.http.wire").exit();
            LogManager.getLogger("org.apache.http.client").exit();
            LogManager.getLogger("org.hibernate").exit();
            LogManager.getLogger("org.apache.http.headers").exit();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("***********************************************************************");
        System.out.println("***********************************************************************");
        System.out.println("executionType: " + System.getProperty("selenium.tests.executionType"));
        System.out.println("moduleNeedToRun: " + System.getProperty("selenium.tests.moduleNeedToRun"));
        System.out.println("threadCount: " + System.getProperty("selenium.tests.threadCount"));
        System.out.println("moduleNoNeedToRun: " + System.getProperty("selenium.tests.moduleNoNeedToRun"));
        System.out.println("runProfile: " + System.getProperty("selenium.tests.runProfile"));
        System.out.println("remoteSeleniumServer: " + System.getProperty("selenium.tests.remoteSeleniumServer"));
        System.out.println("deviceType: " + System.getProperty("selenium.tests.deviceType"));
        System.out.println("user.dir value: " + System.getProperty("user.dir"));
        System.out.println("BuildDirectory value: " + System.getProperty("BuildDirectory"));
        System.out.println("TestResultsRoot value: " + System.getProperty("TestResultsRoot"));
/*		System.out.println("MachineName value: "+System.getProperty("COMPUTERNAME"));
		System.out.println("MSBuildStartupDirectory value: "+System.getProperty("MSBuildStartupDirectory"));
		System.out.println("USERNAME value: "+System.getProperty("USERNAME"));
		System.out.println("BuildAgentName value: "+System.getProperty("BuildAgentName"));
		System.out.println("thread count from XML: "+String.valueOf(testSuite.getXmlSuite().getThreadCount()));
		System.out.println("included group from XML: "+Arrays.toString((testSuite.getXmlSuite().getIncludedGroups()).toArray()));
		System.out.println("Excluded group from XML: "+Arrays.toString((testSuite.getXmlSuite().getExcludedGroups()).toArray()));*/
        System.out.println("***********************************************************************");

        if (System.getenv("testType") != null) {
            testType = System.getenv("testType");
        } else if (System.getProperty("selenium.tests.executionType") != null) {
            testType = System.getProperty("selenium.tests.executionType");
        } else if (System.getenv("selenium.tests.executionType") != null) {
            testType = System.getenv("selenium.tests.executionType");
        }
        if (System.getenv("moduleNeedToRun") != null) {
            moduleNeedToRun.addAll(Arrays.asList(System.getenv("moduleNeedToRun").split(",")));
            testSuite.getXmlSuite().setIncludedGroups(moduleNeedToRun);
        } else if (System.getProperty("selenium.tests.moduleNeedToRun") != null) {
            moduleNeedToRun.addAll(Arrays.asList(System.getProperty("selenium.tests.moduleNeedToRun").split(",")));
            testSuite.getXmlSuite().setIncludedGroups(moduleNeedToRun);
        }

        if (System.getenv("moduleNoNeedToRun") != null) {
            moduleNoNeedToRun.addAll(Arrays.asList(System.getenv("moduleNoNeedToRun").split(",")));
            testSuite.getXmlSuite().setExcludedGroups(moduleNoNeedToRun);
        } else if (System.getProperty("selenium.tests.moduleNoNeedToRun") != null) {
            moduleNoNeedToRun.addAll(Arrays.asList(System.getProperty("selenium.tests.moduleNoNeedToRun").split(",")));
            testSuite.getXmlSuite().setExcludedGroups(moduleNoNeedToRun);
        }

        if (System.getenv("threadCount") != null) {
            threadCount = Integer.parseInt(System.getenv("threadCount"));
            testSuite.getXmlSuite().setThreadCount(threadCount);
        } else if (System.getProperty("selenium.tests.threadCount") != null) {
            threadCount = Integer.parseInt(System.getProperty("selenium.tests.threadCount"));
            testSuite.getXmlSuite().setThreadCount(threadCount);
        }

        if (System.getenv("deviceType") != null) {
            CommonVariables.DeviceName = System.getenv("deviceType");
        } else if (System.getProperty("selenium.tests.deviceType") != null) {
            CommonVariables.DeviceName = System.getProperty("selenium.tests.deviceType");
        }
        testSuite.getXmlSuite().setConfigFailurePolicy("Continue");
        CommonVariables.setTestContext();
        CommonVariables.threadCount = testSuite.getXmlSuite().getThreadCount();
        threadCount = testSuite.getXmlSuite().getThreadCount();
        // testSuite.getXmlSuite().setThreadCount(CommonVariables.threadCount);
    }

}
