package walmart.drone.delivery.automation;

import org.testng.*;

/**
 * http://testng.org/javadoc/org/testng/TestListenerAdapter.html
 *
 * @author Aditya
 */
public class  TestNGTestListener extends TestListenerAdapter implements ITestListener {

    public static TestStatus testStatus = null;

    @Override
    public void onFinish(ITestContext testContext) {
        // TODO Auto-generated method stub

    }

    // This method will call After BeforeSuite and before BeforeTest methods. Both are implemented under com.mystore.utils.TestBase
    @Override
    public void onStart(ITestContext testContext) {
        super.onStart(testContext);
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult testContextResult) {
        // TODO Auto-generated method stub

    }


    /**
     * Runs before every test.
     */
    @Override
    public void onTestStart(ITestResult result) {
        super.onTestStart(result);

        // Automatically create a new TestStatus object and attach it to the
        // test results
        result.setAttribute(CommonVariables.TEST_STATUS_KEY, testStatus);
    }

    /**
     * Runs when a test succeeds.
     */
    @Override
    public void onTestSuccess(ITestResult result) {
        super.onTestSuccess(result);
        if (CommonVariables.CurrentTestCaseLog.get() != null)
            CommonVariables.CurrentTestCaseLog.get().trace("Test success: " + result.getName());
        logValidationResults(getTestStatus());
    }

    /**
     * Runs when a test fails.
     */
    @Override
    public void onTestFailure(ITestResult result) {
        super.onTestFailure(result);
        if (CommonVariables.CurrentTestCaseLog.get() != null)
            CommonVariables.CurrentTestCaseLog.get().error("Test failure: " + result.getName());
        Throwable error = result.getThrowable();
        if (error != null) {
            CommonVariables.CurrentTestCaseLog.get().error(error.toString());
        }
        logValidationResults(getTestStatus());
    }

    /**
     * Runs when a test is skipped.
     */
    @Override
    public void onTestSkipped(ITestResult result) {
        super.onTestSkipped(result);
        if (CommonVariables.CurrentTestCaseLog.get() != null)
            CommonVariables.CurrentTestCaseLog.get().trace("Test skipped: " + result.getName());
    }


    /**
     * Log the validation results to TestNG reporter.
     *
     * @param testStatus
     */
    public void logValidationResults(TestStatus testStatus) {

        ValidationResults results = testStatus.getValidationResults();

        Reporter.setEscapeHtml(false);
        Reporter.log(results.toHtml());

        if (results.getValidationCount() > 0) {
            CommonVariables.CurrentTestCaseLog.get().info("** Test Validation Results **\r\n" + results.toString());
        }
    }

    /**
     * Returns the automatically created TestStatus object attached to this
     * test.
     *
     * @return The current TestStatus object.
     */
    public TestStatus getTestStatus() {
        ITestResult testResult = Reporter.getCurrentTestResult();
        return (TestStatus) testResult.getAttribute(CommonVariables.TEST_STATUS_KEY);
    }

    /**
     * Assert that there were no validation failures
     *
     * @param testStatus
     */
    public void assertAllValidations(TestStatus testStatus) {
        Assert.assertTrue(testStatus.isValid(), testStatus.getValidationResults().toString());
    }

}
