/**
 *
 */
package walmart.drone.delivery.automation;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;


/**
 * @author Aditya
 */
public class CommonJavaUtilsHelper {

    private static final int BUFFER_SIZE = 4096;

    /**
     * <br>
     * description</br>
     *
     * @param format
     * @param timeZone
     * @return
     */
    public static String getServerTime(String format, String timeZone) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
        Calendar c = Calendar.getInstance();
        String fdate = sdf.format(c.getTime());
        return fdate;
    }

    public static Boolean delete(File file) {
        try {
            if (file.isDirectory()) {
                String fileList[] = file.list();
                if (fileList.length == 0) {
                    file.delete();
                } else {
                    int size = fileList.length;
                    for (int i = 0; i < size; i++) {
                        String fileName = fileList[i];
                        String fullPath = file.getPath() + "/" + fileName;
                        File fileOrFolder = new File(fullPath);
                        delete(fileOrFolder);
                    }
                }
                return true;
            } else {
                file.delete();
                return true;
            }
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * <b>Description:</b> Copies the entire src File to Dest
     *
     * @param src
     * @param dest
     * @throws Exception
     * @author Aditya
     */
    public static void staticCopyFile(File src, File dest) throws Exception {
        if (src.isDirectory()) {
            if (!dest.exists()) {
                dest.mkdir();
                System.out.println("Directory copied from " + src + " to " + dest);
            }

            String files[] = src.list();

            for (String file : files) {
                File srcFile = new File(src, file);
                File destFile = new File(dest, file);
                staticCopyFile(srcFile, destFile);
            }

        } else {
            //Files.copy(src.toPath(),dest.toPath(),StandardCopyOption.REPLACE_EXISTING);
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(dest);

            byte[] buffer = new byte[1024];

            int length;
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }

            in.close();
            out.close();
        }
    }

    /**
     * <br>
     * description</br>
     * Verify the presence of a file at a particular location. File name is not
     * case-sensitive and can provide complete/partial name of the file.
     *
     * @param path     - Complete Path of the folder which suppose to contain file
     * @param fileName - Name of the file. It'll compare case
     * @return True, if file found.
     * @author Aditya
     */
    public Boolean verifyPresenceOfFileOrFolderAtLocation(String path, String fileName) {
        try {
            File file = new File(path);
            File[] listOfFiles = file.listFiles();
            if (listOfFiles.length != 0) {
                for (int i = 0; i < listOfFiles.length; i++) {
                    if (listOfFiles[i].getName().toLowerCase().contains(fileName.toLowerCase())) {
                        return true;
                    }
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * <b>Description:</b> Copies the entire src File to Dest
     *
     * @param src
     * @param dest
     * @throws Exception
     * @author Aditya
     */
    public void copyFile(File src, File dest) throws Exception {
        if (src.isDirectory()) {
            if (!dest.exists()) {
                dest.mkdir();
                System.out.println("Directory copied from " + src + " to " + dest);
            }
            String files[] = src.list();
            for (String file : files) {
                File srcFile = new File(src, file);
                File destFile = new File(dest, file);
                copyFile(srcFile, destFile);
            }
        } else {
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(dest);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }
            in.close();
            out.close();
        }
    }

    /**
     * @param data
     * @param filePath
     */
    public void writeAppendDataInFile(String data, String filePath) {
        try {
            FileWriter fw;
            PrintWriter pw;
            fw = new FileWriter(filePath, true);
            pw = new PrintWriter(fw);
            pw.write(data);
            pw.write("\n");
            pw.close();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * <br>description</br>
     *
     * @param startTime -  Start Time as a Date class object
     * @param endTime   - End Time as a Date class object
     * @author: z001nhb
     */
    public Double getTimeDifferenceInMin(Date startTime, Date endTime) {
        Double ageInMillis = (double) (endTime.getTime() - startTime.getTime());
        return ageInMillis / (1000 * 60);
    }

}
