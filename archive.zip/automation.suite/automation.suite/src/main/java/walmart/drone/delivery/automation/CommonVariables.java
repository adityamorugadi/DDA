/**
 *
 */
package walmart.drone.delivery.automation;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.BufferedWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Aditya
 */
public class CommonVariables {
    public static TestContext _testContext = null;
    public static DetailedLogs DL = new DetailedLogs();
    public static String environment = "";
    public static ThreadLocal<WebDriver> CommonDriver = new ThreadLocal<WebDriver>();
    public static ThreadLocal<String> CurrentTestCaseName = new ThreadLocal<String>();
    public static ThreadLocal<String> CurrentTestClassName = new ThreadLocal<String>();
    public static ThreadLocal<String> CurrentTestClassResult = new ThreadLocal<String>();
    public static ThreadLocal<Logger> CurrentTestCaseLog = new ThreadLocal<Logger>();
    public static ThreadLocal<String> CurrentTestCaseResult = new ThreadLocal<String>();
    public static ThreadLocal<Logger> CurrentTestClassLog = new ThreadLocal<Logger>();
    public static Logger CurrentGlobalLog = null;
    public static BufferedWriter HighLevelLog = null;
    public static String RootResultFolderPath = new String("");
    public static ThreadLocal<String> ScenarioResultFolderPath = new ThreadLocal<String>();
    public static ThreadLocal<String> ScenarioScreenShotFolderPath = new ThreadLocal<String>();
    public static ThreadLocal<String> TCResultFolderPath = new ThreadLocal<String>();
    public static ThreadLocal<String> CurrentTCLogPath = new ThreadLocal<String>();
    public static ThreadLocal<Integer> TestCase_Data_Iterator = new ThreadLocal<Integer>();
    public static ArrayList<String> ScenariosHighLevelLog = new ArrayList<String>();
    public static ThreadLocal<ArrayList<String>> TestCasessHighLevelLog = new ThreadLocal<ArrayList<String>>();
    public static String DeviceName = new String();
    public static String PlatformName = new String();
    public static ThreadLocal<Integer> DataProviderIterator = new ThreadLocal<Integer>();
    public static ThreadLocal<String> TCStartTime = new ThreadLocal<String>();
    public static ThreadLocal<String> TCEndTime = new ThreadLocal<String>();
    public static ThreadLocal<String> ExecutionDate = new ThreadLocal<String>();
    public static ThreadLocal<String> ExecutionStartTime = new ThreadLocal<String>();
    public static ThreadLocal<String> ExecutionEndTime = new ThreadLocal<String>();
    public static ThreadLocal<Integer> TotalTCCount = new ThreadLocal<Integer>();
    public static ThreadLocal<Integer> PassTCCount = new ThreadLocal<Integer>();
    public static ThreadLocal<Integer> FailTCCount = new ThreadLocal<Integer>();
    public static ThreadLocal<Integer> SkipTCCount = new ThreadLocal<Integer>();
    public static ThreadLocal<String> GlobalHTMLReportPath = new ThreadLocal<String>();
    public static ThreadLocal<WebDriverHelper> _webDriverHelper = new ThreadLocal<WebDriverHelper>();
    public static ThreadLocal<Boolean> IsGridExecution = new ThreadLocal<Boolean>();
    public static ThreadLocal<Map<String, String>> UserDetail = new ThreadLocal<Map<String, String>>();
    public static ThreadLocal<String> PortNumber = new ThreadLocal<String>();
    public static Boolean DebugMode = false;
    public static Map<String, String> ResultSheet = new HashMap<String, String>();
    public static Map<String, String> TestMethodDescriptions = new HashMap<String, String>();
    public static Boolean EmailReport = false;
    public static ThreadLocal<String> LastMethodName = new ThreadLocal<String>();
    public static String MachineHostName = new String();
    public static ThreadLocal<String> SeleniumGridNodeIP = new ThreadLocal<String>();
    public static Integer portNumForBMP = 8019;
    public static String testNGGroupNames = "";
    public static ThreadLocal<String> machineIP = new ThreadLocal<String>();
    public static Integer threadCount = new Integer(1);
    public static String TEST_STATUS_KEY = "_TEST_STATUS_";

    /**
     * <b>Description:</b> This is setter for WebDriverHelper.
     *
     * @throws ConfigurationException
     */
    public static void setCommonFunctionLib() throws ConfigurationException {
        if (getCommonFunctionLib() == null)
            _webDriverHelper.set(new WebDriverHelper(CommonDriver.get()));
    }

    /**
     * <b>Description:</b> This is getter for WebDriverHelper.
     *
     * @return Instance of WebDriverHelper
     */
    public static WebDriverHelper getCommonFunctionLib() {
        return _webDriverHelper.get();
    }

    /**
     * <b>Description:</b> This is setter for TestContext.
     */
    public static void setTestContext() {
        if (getTestContext() == null)
            _testContext = new TestContext();
    }

    /**
     * <b>Description:</b> This is getter for TestContext.
     *
     * @return Instance of TestContext
     */
    public static TestContext getTestContext() {
        return _testContext;
    }

    /**
     * <b>Description:</b> This is getter for WebDriver.
     *
     * @return Instance of CommonFunctionLib
     */
    public static WebDriver getDriver() {
        return CommonDriver.get();
    }

    /**
     * <b>Description:</b> This is setter for WebDriver.
     */
    public static void setDriver(WebDriver driver) {
        CommonDriver.set(driver);
    }

    public static void setDriverToNull() {
        CommonDriver.set(null);
    }

    public static WebDriver SwitchToiFrame(WebElement frame_element) {
        CommonDriver.get().switchTo().frame(frame_element);
        getCommonFunctionLib().setDriver(CommonDriver.get());
        return CommonDriver.get();
    }

    public static WebDriver SwitchBackFromiFrameToMaincontent() {
        CommonDriver.get().switchTo().defaultContent();
        getCommonFunctionLib().setDriver(CommonDriver.get());
        return CommonDriver.get();
    }
}
