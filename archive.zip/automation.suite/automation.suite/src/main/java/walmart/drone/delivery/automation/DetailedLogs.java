/**
 *
 */
package walmart.drone.delivery.automation;

/**
 * @author Aditya
 */

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Appender;
import org.apache.logging.log4j.core.Layout;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.appender.FileAppender;
import org.apache.logging.log4j.core.config.AppenderRef;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.Configurator;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.apache.logging.log4j.core.layout.PatternLayout;

import java.io.File;
import java.io.IOException;

/**
 * @author Aditya
 *
 */

/**
 * @author Aditya
 *
 */
public class DetailedLogs {
    //public static Logger APP_LOGS=null;
    LoggerContext context = null;

    public org.apache.logging.log4j.Logger startDefaultAppender(String LogName, String location) throws IOException {
        File fl = new File(location);
        System.setProperty("logFilepath", fl.getPath());
        //System.setProperty("-DlogFilepath", fl.getPath());
        context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
        File file = new File(System.getProperty("user.dir") + "/src/log4j2.xml");
        // this will force a reconfiguration
        context.setConfigLocation(file.toURI());
//		context.reconfigure();
        Configuration config = context.getConfiguration();
        LoggerConfig rootConfig = config.getLoggerConfig(LogManager.ROOT_LOGGER_NAME);
        rootConfig.setLevel(Level.TRACE);
        org.apache.logging.log4j.Logger log = LogManager.getLogger(LogName);
        return log;
    }


    public void createFolder(String location) {
        new File(location).mkdir();

    }

    /**
     * Normally there is no need to do this manually.
     * Each LoggerContext registers a shutdown hook that takes care of releasing resources
     * when the JVM exits (unless system property log4j.shutdownHookEnabled is set to false)
     */
    public void shutDownLog4J() {
        // get the current context
        //LoggerContext context = (LoggerContext) LogManager.getContext();
        Configurator.shutdown(context);
    }

    public org.apache.logging.log4j.Logger startLogs(String LogName, String location) {
        java.util.logging.Logger.getLogger("org.apache.http.wire").setLevel(java.util.logging.Level.OFF);
        java.util.logging.Logger.getLogger("org.apache.http.client").setLevel(java.util.logging.Level.OFF);
        java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.OFF);
        java.util.logging.Logger.getLogger("org.apache.http.headers").setLevel(java.util.logging.Level.OFF);
        try {
            LogManager.getLogger("org.apache.http.wire").exit();
            LogManager.getLogger("org.apache.http.client").exit();
            LogManager.getLogger("org.hibernate").exit();
            LogManager.getLogger("org.apache.http.headers").exit();
        } catch (Exception e) {
        }
/*		System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.SimpleLog");
		System.setProperty("org.apache.commons.logging.simplelog.showdatetime", "true");
		System.setProperty("org.apache.commons.logging.simplelog.log.httpclient.wire", "ERROR");
		System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http", "ERROR");
		System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http.headers", "ERROR");*/
        final LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
        final Configuration config = ctx.getConfiguration();
        Layout layout = PatternLayout.createLayout("%d{dd/MM/yyyy 'at' HH:mm:ss.SSS}\t%-5level\t%class{36}:%M\t%c\t%msg%n", null, config, null,
                null, true, false, null, null);
        Appender appender = FileAppender.createAppender(location, "true", "false", LogName, "true",
                "false", "true", "4000", layout, null, "false", null, config);
        appender.start();
        config.addAppender(appender);
        AppenderRef ref = AppenderRef.createAppenderRef("File", null, null);
        AppenderRef[] refs = new AppenderRef[]{ref};
        LoggerConfig loggerConfig = LoggerConfig.createLogger("false", Level.DEBUG, LogName,
                "true", refs, null, config, null);
        loggerConfig.addAppender(appender, null, null);
        config.addLogger(LogName, loggerConfig);
        ctx.updateLoggers();
        return LogManager.getLogger(LogName);
    }
}
