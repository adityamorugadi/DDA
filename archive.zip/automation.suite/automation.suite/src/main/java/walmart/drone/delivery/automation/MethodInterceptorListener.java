/**
 *
 */
package walmart.drone.delivery.automation;

import org.apache.logging.log4j.core.net.Priority;
import org.testng.IMethodInstance;
import org.testng.IMethodInterceptor;
import org.testng.ITestContext;

import java.util.*;

/**
 * @author Aditya
 */
public class MethodInterceptorListener implements IMethodInterceptor {

    public MethodInterceptorListener() {
    }

    @Override
    public List<IMethodInstance> intercept(List<IMethodInstance> methods, ITestContext context) {
        List<IMethodInstance> finalListofMethods = Collections.synchronizedList(new ArrayList<IMethodInstance>());
        finalListofMethods = getFinalListofMethod(methods);
        return finalListofMethods;
    }

    private List<IMethodInstance> getFinalListofMethod(List<IMethodInstance> methods) {
/*		System.out.println("************************************************************");
		System.out.println("testType : "+TestNGStarterFinishListener.testType);
		System.out.println("Final computed list of module which Need To Run : "+String.valueOf(TestNGStarterFinishListener.moduleNeedToRun));
		System.out.println("************************************************************");
*/
        List<IMethodInstance> finalListofMethods = Collections.synchronizedList(new ArrayList<IMethodInstance>());
        for (IMethodInstance m : methods) {
            String[] testMethodGroupName = m.getMethod().getGroups();
            boolean include = true;
            if (!TestNGStarterFinishListener.testType.isEmpty()) {
                if (!searchValueInArray(TestNGStarterFinishListener.testType, testMethodGroupName)) {
                    include = false;
                }
            }
            if (include && (TestNGStarterFinishListener.moduleNeedToRun.size() > 0 || TestNGStarterFinishListener.moduleNoNeedToRun.size() > 0)) {
                //org.apache.commons.lang3.StringUtils.join(TestNGStarterFinishListener.moduleNeedToRun)
                System.out.println(Arrays.toString(TestNGStarterFinishListener.moduleNeedToRun.toArray()).replace("[", "").replace("]", ""));
                if (!(Arrays.toString(TestNGStarterFinishListener.moduleNeedToRun.toArray()).replace("[", "").replace("]", "").isEmpty()
                        || havingAnySimilarItemInTwolist(testMethodGroupName, TestNGStarterFinishListener.moduleNeedToRun))) {
                    include = false;
                }
                if (include && TestNGStarterFinishListener.moduleNoNeedToRun.size() > 0) {
                    if ((havingAnySimilarItemInTwolist(testMethodGroupName, TestNGStarterFinishListener.moduleNoNeedToRun)))
                        include = false;
                }
            }
            if (include) {
                finalListofMethods.add(m);

            }
        }
/*		System.out.println(
				"************* Total number of test methods found in current Test/Thead level: " + methods.size()
						+ " \n *********** After apply filter criteria, final number of TestMethod which need to execute: "
						+ finalListofMethods.size());*/

        // http://stackoverflow.com/questions/26632241/priority-in-testng-with-multiple-classes

        Comparator<IMethodInstance> comparator = new Comparator<IMethodInstance>() {
            private int getPriority(IMethodInstance mi) {
                Integer result = null;
                result = mi.getMethod().getPriority();
                if (result == 0) {
                    Priority classPriority = (Priority) mi.getMethod().getRealClass().getAnnotation(Priority.class);
                    if (classPriority != null) {
                        result = classPriority.getValue();
                    }
                }
                return result;
            }

            public int compare(IMethodInstance m1, IMethodInstance m2) {
                return getPriority(m1) - getPriority(m2);
            }
        };
        IMethodInstance[] array = finalListofMethods.toArray(new IMethodInstance[finalListofMethods.size()]);
        Arrays.sort(array, comparator);
        return finalListofMethods;
    }

    private boolean havingAnySimilarItemInTwolist(String[] searchFor, List<String> searchFrom) {
        boolean havingSimilarItem = false;
        for (String expected : searchFor) {
            //System.out.println("expected: "+expected);
            for (String actual : searchFrom) {
                //System.out.println("actual: "+actual);
                if (actual.equalsIgnoreCase(expected)) {
                    return true;
                }
            }
        }
        return havingSimilarItem;
    }

    private boolean searchValueInArray(String valueNeedToSearch, String[] arraySearchFrom) {
        for (String val : arraySearchFrom) {
            if (val.equalsIgnoreCase(valueNeedToSearch)) {
                return true;
            }
        }
        return false;
    }

}

/**
 * Wiki
 * ITestContext: This class defines a test context which contains all the information for a given test run. An instance of this context is passed to the test listeners so they can query information about their environment.
 * ITestContext is passed in the intercept method so that implementers can set user values (using IAttributes.setAttribute(String, Object)), which they can then look up later while generating the reports.
 * IMethodInterceptor: This class is used to alter the list of test methods that TestNG is about to run.
 * Typically, the returned list will be just the methods passed in parameter but sorted differently, but it can actually have any size (it can be empty, it can be of the same size as the original list or it can contain more methods).
 */

/*
We need to add this extra node in the testng xml just before the test

<listeners>
		<listener class-name="com.mystore.utils.MethodInterceptorListener"></listener>
</listeners>
*/