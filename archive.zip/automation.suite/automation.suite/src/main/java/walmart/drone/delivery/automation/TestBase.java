package walmart.drone.delivery.automation;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.*;
import org.testng.*;
import org.testng.annotations.*;

import java.io.*;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;

/**
 * Base class for Selenium tests. Provides a variety of helper methods that are
 * useful across all tests.
 */
@Listeners({TestBase.class})
public class TestBase extends TestListenerAdapter {

    public static ThreadLocal<TestStatus> testStatus = new ThreadLocal<TestStatus>();
    public static int threadCount = 1;
    public static int iTimeout;
    static String timestamp = "";
    // final static String TEST_STATUS_KEY = "_TEST_STATUS_";
    public WebDriver _driver = null;
    public String emailToAddress;
    public int itr_cnt = 1;
    //protected static final Logger log = LogManager.getLogger("SeleniumTests");
    protected WebDriverHelper _webDriverHelper;
    Calendar startTime;
    Calendar endTime;
    private String emailFrom = "";
    private String emailPass = "";

    /**
     * Initialize the TestContext object loading the properties from the default
     * properties file ("config.properties")
     */
    public static void initializeTestContext() {
        CommonVariables.setTestContext();
    }

    /**
     * Initialize the TestContext object loading the properties from the
     * supplied properties file.
     *
     * @param propertiesFile Path to a properties file containing properties for this test.
     */
    public static void initializeTestContext(String propertiesFile) {
        CommonVariables.setTestContext();
    }

    /**
     * Retrieve the TestContext object for this test.
     *
     * @return The TestContext object for this test.
     */
    public static TestContext getContext() {
        return CommonVariables.getTestContext();
    }

    @BeforeSuite(alwaysRun = true, description = "Configure Test Execution parameters.")
    public void beforeSuite(ITestContext context) throws Exception {
        if (!TestContext.ArePropertiesSet) {
            CommonVariables.setTestContext();
        }
        try {
            LogManager.getLogger("org.apache.http.wire").exit();
            LogManager.getLogger("org.apache.http.client").exit();
            LogManager.getLogger("org.hibernate").exit();
            LogManager.getLogger("org.apache.http.headers").exit();
        } catch (Exception e) {
        }
        emailToAddress = "aditya@walmartlabs.com";
        CommonVariables.testNGGroupNames = context.getIncludedGroups().toString();
        timestamp = CommonJavaUtilsHelper.getServerTime("yyyy_MM_dd_hh_mm_sss_a", "GMT+5:30");
        // dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        startTime = Calendar.getInstance();
        String Report_Root_Path = System.getProperty("user.dir") + "/logs/Results/" + timestamp;
        CommonVariables.DL.createFolder(Report_Root_Path);
        CommonVariables.RootResultFolderPath = Report_Root_Path;
        //CommonVariables.ScenariosHighLevelLog=new ArrayList<String>();
        CommonVariables.CurrentGlobalLog = (CommonVariables.DL.startLogs("Global_Log", Report_Root_Path + "/global.log"));
        CommonVariables.CurrentGlobalLog.info("Running on machine: " + InetAddress.getLocalHost().getHostName());
        File src = null;
        File dest = null;
        try {
            src = new File(System.getProperty("user.dir") + "/test-output/testng-failed.xml");
            dest = new File(System.getProperty("user.dir") + "/lastRunResultFolder.txt");
            if (dest.exists()) {
                BufferedReader in = new BufferedReader(new FileReader(dest));
                String destString;
                while ((destString = in.readLine()) != null) {
                    dest = new File(destString + "/testng-failed.xml");
                }
                CommonJavaUtilsHelper.staticCopyFile(src, dest);
                in.close();
            } else {
                CommonJavaUtilsHelper.staticCopyFile(src, new File(System.getProperty("user.dir")
                        + "/logs/Unknown-testNgFailed/test-failed" + System.nanoTime() + ".xml"));
            }
            CommonVariables.CurrentGlobalLog
                    .info("copied last TestNG failed file into logs/Unknown-testNgFailed location successfully.");
        } catch (Exception e1) {
        }
        File highlevellogfile = new File(CommonVariables.RootResultFolderPath + "/" + "HighLevelLog" + ".log");
        FileWriter highlevellogfw = new FileWriter(highlevellogfile.getAbsoluteFile());
        CommonVariables.HighLevelLog = new BufferedWriter(highlevellogfw);
    }

    @BeforeTest(alwaysRun = true)
    public void beforeTest(ITestContext context) throws IOException, InterruptedException {
        // Set-up CommonVariables
        String hostname = InetAddress.getLocalHost().getHostName();
        CommonVariables.MachineHostName = hostname;
        /*
         * Currently set as Hard code values of below two parameters because we
         * are currently running only on Windows-Chrome.
         */
        CommonVariables.DeviceName = CommonVariables.getTestContext().getStringProperty("deviceType",
                "chrome");
        CommonVariables.PlatformName = "";
        CommonVariables.ExecutionDate
                .set(CommonJavaUtilsHelper.getServerTime("yyyy/MM/dd HH:mm:ss a", "GMT+5:30").split(" ")[0]);
        CommonVariables.ExecutionStartTime
                .set(CommonJavaUtilsHelper.getServerTime("yyyy/MM/dd HH:mm:ss a", "GMT+5:30"));
        if (getContext().getStringProperty("isGridExecution", "false").equalsIgnoreCase("true"))
            CommonVariables.IsGridExecution.set(true);
        else {
            CommonVariables.IsGridExecution.set(false);
        }
        if (getContext().getStringProperty("emailReport", "false").equalsIgnoreCase("true"))
            CommonVariables.EmailReport = true;
        else {
            CommonVariables.EmailReport = false;
        }
        if (getContext().getStringProperty("debugMode", "false").equalsIgnoreCase("true"))
            CommonVariables.DebugMode = true;
        else {
            CommonVariables.DebugMode = false;
        }
        emailFrom = CommonVariables.getTestContext().getStringProperty("emailForNotification",
                "myDeviceSeleniumtestautomation@gmail.com");
        emailPass = CommonVariables.getTestContext().getStringProperty("emailForNotificationPass", "Walmart@123");
        iTimeout = CommonVariables.getTestContext().getIntProperty("globalTimeOut", 60);
    }

    /**
     * Before Class method, which suppose to initialize WebDriverHelper Class
     * and create Driver, if not created yet.
     *
     * @throws Exception
     */

    @BeforeClass(alwaysRun = true)
    public void beforeAllClass() throws Exception {
        // super.setUpClass();
        try {
            if (threadCount != 1) Thread.sleep(2000);
            threadCount = threadCount + 1;
        } catch (InterruptedException ex) {
        }
        initializeTestContext();
        CommonVariables.CurrentTestCaseName.set("");
        CommonVariables.TotalTCCount.set(new Integer(0));
        CommonVariables.PassTCCount.set(new Integer(0));
        CommonVariables.FailTCCount.set(new Integer(0));
        CommonVariables.SkipTCCount.set(new Integer(0));
        CommonVariables.CommonDriver.set(null);
        CommonVariables.LastMethodName.set("");
        CommonVariables.CurrentTestClassResult.set("PASS");
        //Use to maintain high level complete Class result
        CommonVariables.TestCasessHighLevelLog.set(new ArrayList<String>());
        String completeclassName = this.getClass().getName();
        System.out.println("Running the TestClass: " + completeclassName);
        String[] sArr = completeclassName.split("\\.");
        int last_array_item_index = sArr.length - 1;
        String className = sArr[last_array_item_index];
        String classLogName = className + "_" + Thread.currentThread().getId();
        CommonVariables.CurrentTestClassName.set(className);
        String Scenario_Report_Folder = CommonVariables.RootResultFolderPath + "/" + className;
        CommonVariables.DL.createFolder(Scenario_Report_Folder);
        CommonVariables.ScenarioResultFolderPath.set(Scenario_Report_Folder);
        String TestCases_Report_Folder = CommonVariables.ScenarioResultFolderPath.get() + "/" + "TestCases";
        CommonVariables.DL.createFolder(TestCases_Report_Folder);
        String TestCases_ScreenShot_Folder = CommonVariables.ScenarioResultFolderPath.get() + "/" + "ScreenShots";
        CommonVariables.DL.createFolder(TestCases_ScreenShot_Folder);
        CommonVariables.CurrentTestClassLog.set(CommonVariables.DL.startLogs(classLogName, Scenario_Report_Folder + "/" + classLogName + ".log"));
        //CommonVariables.CurrentTestClassLog.get().info("******** " + className + " Started *************");
        CommonVariables.setCommonFunctionLib();
        //CommonVariables.CurrentTestClassLog.get().debug("In Before Class method inside " + this.getClass().getName());
        CommonVariables.CurrentTestCaseResult.set("");
        CommonVariables.CommonDriver.set(null);
        //CommonVariables.CurrentTestClassLog.get().info("Start Time: "+CommonJavaUtilsHelper.getServerTime("yyyy/MM/dd_hh:mm:sss_a", "GMT+5:30"));
    }

    @BeforeMethod(alwaysRun = true, inheritGroups = true)
    public void beforeTestCase(Method method, ITestResult result) {
        try {
            String testName = method.getName();
//			String[] sArr = this.getClass().getName().split("\\.");
//			CommonVariables.CurrentTestClassName.set(sArr[sArr.length - 1]);
            CommonVariables.CurrentTestClassLog.get().info("Started Method:" + testName);
            String testClassName = CommonVariables.CurrentTestClassName.get();
            String testcaseLogName = testClassName + "-" + testName + "_" + Thread.currentThread().getId();
            CommonVariables.ScenarioResultFolderPath.set(CommonVariables.RootResultFolderPath + "/" + CommonVariables.CurrentTestClassName.get());
/*			CommonVariables.CurrentTestCaseLog.get().trace("============= TEST START ==============");
			CommonVariables.CurrentTestCaseLog.get().trace("Test Name: " + testName);*/
            if (CommonVariables.CurrentTestCaseName.get().equals(testName)) {
                if (CommonVariables.CurrentTestCaseLog.get() != null) {
                    CommonVariables.TestCase_Data_Iterator.set(CommonVariables.TestCase_Data_Iterator.get() + 1);
                    CommonVariables.CurrentTestCaseLog.get().info("***************************   Dataprovider Iteration No: "
                            + CommonVariables.TestCase_Data_Iterator.get()
                            + " :************************************");
                } else {
                    CommonVariables.DataProviderIterator.set(1);
                    CommonVariables.CurrentTestCaseName.set(testName);
                    CommonVariables.TestCase_Data_Iterator.set(CommonVariables.TestCase_Data_Iterator.get() + 1);
                    CommonVariables.CurrentTestCaseLog.set(CommonVariables.DL.startLogs(testcaseLogName,
                            CommonVariables.ScenarioResultFolderPath.get() + "/" + "TestCases"));
                    CommonVariables.CurrentTestCaseLog.get().info("***************************   Dataprovider Iteration No: "
                            + CommonVariables.TestCase_Data_Iterator.get()
                            + " :************************************");
                }
            } else {
                CommonVariables.CurrentTestCaseName.set(testName);
                CommonVariables.TestCase_Data_Iterator.set(1);
                CommonVariables.CurrentTestCaseLog.set(CommonVariables.DL.startLogs(testcaseLogName,
                        CommonVariables.ScenarioResultFolderPath.get() + "/" + "TestCases/" + testcaseLogName + ".log"));
                CommonVariables.CurrentTestCaseLog.get().trace("============= TEST START ==============");
                CommonVariables.CurrentTestCaseLog.get().info("***************************   Dataprovider Iteration No: "
                        + CommonVariables.TestCase_Data_Iterator.get()
                        + " :************************************");
            }
            CommonVariables.TCStartTime.set(CommonJavaUtilsHelper.getServerTime("yyyy_MM_dd_hh_mm_sss_a", "GMT+5:30"));
        } catch (Exception ex) {
            CommonVariables.CurrentTestCaseLog.get().error(
                    "Getting exception in TestBase class beforeMethod. Exception message:" + ex.getLocalizedMessage());
        }
    }

    @AfterMethod(alwaysRun = true, inheritGroups = true)
    public void afterTestMethods(Method method, ITestResult result) {

        //*** code to get the Method Description ****************************************************************
        String MethodDescription = "";
        java.lang.annotation.Annotation[] annotations = method.getAnnotations();
        for (java.lang.annotation.Annotation annotation : annotations) {
            if (annotation instanceof org.testng.annotations.Test) {
                org.testng.annotations.Test myAnnotation = (org.testng.annotations.Test) annotation;
                MethodDescription = myAnnotation.description().toString().replace(",", ";");
            }
        }
        String testName = method.getName();
        CommonVariables.CurrentTestCaseName.set(testName);
        String DataParameters = "";
        try {
            String[] TestCasePArametersArray = (String[]) result.getParameters()[0];
            DataParameters = Arrays.toString(TestCasePArametersArray);
        } catch (java.lang.ClassCastException e) {
            try {
                try {
                    Object[] arrDataObj = (Object[]) result.getParameters()[0];
                    for (Object obj : arrDataObj) {
                        DataParameters = DataParameters + obj.toString() + "||";
                    }
                } catch (java.lang.ClassCastException e1) {
                }
            } catch (java.lang.ClassCastException e1) {
                DataParameters = Arrays.toString(result.getParameters());
            }
        } catch (Exception e) {
            DataParameters = Arrays.toString(result.getParameters());
            //			  e.printStackTrace();
        }
        if (DataParameters.equals("[]"))
            DataParameters = "";
        CommonVariables.TotalTCCount.set(CommonVariables.TotalTCCount.get() + 1);
        CommonVariables.TCEndTime.set(CommonJavaUtilsHelper.getServerTime("yyyy_MM_dd_hh_mm_sss_a", "GMT+5:30"));
        String CompleteTCName = CommonVariables.CurrentTestClassName.get() + "." + testName;
        String TestCaseResult = "";
        if (result.getStatus() == ITestResult.FAILURE) {
            TestCaseResult = "FAIL";
            CommonVariables.CurrentTestClassResult.set("FAIL");
            //			  CommonVariables.CurrentTestCaseResult = "FAIL";
            CommonVariables.FailTCCount.set(CommonVariables.FailTCCount.get() + 1);
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            TestCaseResult = "PASS";
            CommonVariables.PassTCCount.set(CommonVariables.PassTCCount.get() + 1);
        } else if (result.getStatus() == ITestResult.SKIP) {
            TestCaseResult = "SKIP";
            CommonVariables.SkipTCCount.set(CommonVariables.SkipTCCount.get() + 1);
        } else {
            TestCaseResult = "UNKNOWN";
        }
        String TestDescriptionKey = CommonVariables.CurrentTestClassName.get() + "-" + CommonVariables.CurrentTestCaseName.get();
        if (CommonVariables.LastMethodName.get().equals(testName)) {
            itr_cnt++;
        } else {
            itr_cnt = 1;
        }
        String NewCompleteTCName = CompleteTCName + ">Itr" + itr_cnt;
        CommonVariables.ResultSheet.put(NewCompleteTCName, CompleteTCName + "," + itr_cnt + "," + TestCaseResult + "," + CommonVariables.PlatformName + "-" + CommonVariables.DeviceName + "," + MethodDescription);
        CommonVariables.TestMethodDescriptions.put(TestDescriptionKey, MethodDescription);
        CommonVariables.CurrentTestCaseResult.set(TestCaseResult);
        CommonVariables.TestCasessHighLevelLog.get().add(CommonVariables.CurrentTestCaseName.get() + ":" + TestCaseResult + ":" + DataParameters);
        CommonVariables.CurrentTestClassLog.get().info(CommonVariables.CurrentTestCaseName.get() + ":" + TestCaseResult + ":" + DataParameters);
        CommonVariables.LastMethodName.set(testName);
        try {
            CommonVariables.CurrentGlobalLog.info(CommonVariables.CurrentTestClassName.get() + "\t" + CommonVariables.CurrentTestCaseName.get() + "\t" + TestCaseResult + "\t" + DataParameters + "\t" + CommonVariables.TCStartTime.get() + "\t" + CommonVariables.TCEndTime.get() + "\t" + StringUtils.join(result.getMethod().getGroups(), ",") + "\r\n");
            CommonVariables.HighLevelLog.write(CommonVariables.CurrentTestClassName.get() + "\t" + CommonVariables.CurrentTestCaseName.get() + "\t" + TestCaseResult + "\t" + DataParameters + "\t" + CommonVariables.TCStartTime.get() + "\t" + CommonVariables.TCEndTime.get() + "\t" + StringUtils.join(result.getMethod().getGroups(), ",") + "\r\n");
        } catch (IOException e) {
            CommonVariables.CurrentTestClassLog.get().error("Failed to write HighlevelLog: Log message: " + CommonVariables.CurrentTestClassName.get() + "\t" + CommonVariables.CurrentTestCaseName.get() + "\t" + TestCaseResult + "\t" + DataParameters + "\t" + CommonVariables.TCStartTime.get() + "\t" + CommonVariables.TCEndTime.get() + "\t" + "-" + "\t" + "-" + "\t" + "-" + "\r\n");
            e.printStackTrace();
        }
    }

    @AfterClass(alwaysRun = true, inheritGroups = true)
    public void tearDownClasses() throws Exception {
        // Close Driver.
        CommonVariables.getCommonFunctionLib().closeDriver();
        _driver = null;
        //Set overall Test Class result
        //CommonVariables.CurrentTestClassLog.get().info("End Time: "+CommonJavaUtilsHelper.getServerTime("yyyy_MM_dd_hh_mm_sss_a", "GMT+5:30"));
        CommonVariables.CurrentTestClassLog.get().trace("Stopping the Test Class.");

        if (CommonVariables.CurrentTestClassResult.get().equalsIgnoreCase("PASS")) {
            CommonVariables.ScenariosHighLevelLog.add(CommonVariables.CurrentTestClassName.get() + ": PASS");
        } else {
            CommonVariables.ScenariosHighLevelLog.add(CommonVariables.CurrentTestClassName.get() + ": FAIL");
        }
//		CommonVariables.CurrentTestClassLog.get().info("TC Passed-"+CommonVariables.PassTCCount.get()+":: TC Failed-"+CommonVariables.FailTCCount.get()+":: TC Skipped-"+CommonVariables.SkipTCCount.get());
        // Create HTML of individual Test Method log files under a Test Class.
        String ReportPath = CommonVariables.ScenarioResultFolderPath.get() + "/TestCases/";
        File dir = new File(ReportPath);
        if (dir.isDirectory()) {
            File[] directoryListing = dir.listFiles();
            if (directoryListing != null) {
                HTMLReporting htmlreporting = new HTMLReporting();
                for (File file : directoryListing) {
                    if (!file.isDirectory()) {
                        if (FilenameUtils.getExtension(file.getPath()).contains("log")) {
//							htmlreporting.ConvertLogToHtml(ReportPath,
//									FilenameUtils.removeExtension(file.getName().toString()),Logtype.MethodLevel);
                        }
                    }
                }
            }
        }

        String subject = "";
        if (CommonVariables.CurrentTestClassResult.get().toUpperCase().contains("FAIL")) {
            subject = subject + "FAILED:Drone Delivery Automation Results: " + CommonVariables.PlatformName + " - " + CommonVariables.DeviceName + " - " + timestamp;
        } else if (CommonVariables.TotalTCCount.get() <= CommonVariables.SkipTCCount.get()) {
            subject = subject + "ALL SKIPPED :Drone Delivery Automation Results: " + CommonVariables.PlatformName + " - " + CommonVariables.DeviceName + " - " + timestamp;
        } else {
            subject = subject + "PASSED:Drone Delivery Automation Results: " + CommonVariables.PlatformName + " - " + CommonVariables.DeviceName + " - " + timestamp;
        }
        subject = CommonVariables.getTestContext().getStringProperty("storeId") + subject;
        ReportPath = CommonVariables.ScenarioResultFolderPath.get();
        dir = new File(ReportPath);
        if (dir.isDirectory()) {
            File[] directoryListing = dir.listFiles();
            if (directoryListing != null) {
                HTMLReporting htmlreporting = new HTMLReporting();
                for (File file : directoryListing) {
                    if (!file.isDirectory()) {
                        if (FilenameUtils.getExtension(file.getPath()).contains("log")) {
                            try {
                                htmlreporting.ConvertLogToHtml(ReportPath,
                                        FilenameUtils.removeExtension(file.getName().toString()), HTMLReporting.Logtype.ClassLevel);
                                String HTMLReportPath = ReportPath + "/"
                                        + FilenameUtils.removeExtension(file.getName().toString()) + ".html";
//								CommonJavaUtilsHelper.sendEmailReport(emailFrom, emailPass, emailToAddress.split("//;"),
//										subject, HTMLReportPath);
                            } catch (Exception ex) {

                            }
                        }
                    }
                }
            }
        }
    }

    @AfterSuite(alwaysRun = true)
    public void aftetSuite(ITestContext context) {
        endTime = Calendar.getInstance();
        try {
            CommonVariables.HighLevelLog.close();
            CommonVariables.ExecutionEndTime.set(CommonJavaUtilsHelper.getServerTime("yyyy/MM/dd HH:mm:ss a", "GMT+5:30"));
            HTMLReporting htmlreporting = new HTMLReporting();
            htmlreporting.ConvertHighLevelLogToHtml(context, CommonVariables.RootResultFolderPath, "HighLevelLog");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if (CommonVariables.CurrentGlobalLog != null) {
            CommonVariables.CurrentGlobalLog.info("End Time:" + endTime.getTime().toString());
            String[] group = context.getIncludedGroups();
            CommonVariables.CurrentGlobalLog.info("Group Added, if any: " + Arrays.toString(group));
            if (_webDriverHelper != null) {
                double totalExecutionTime = _webDriverHelper.getTimeDifferenceInMin(startTime.getTime(),
                        endTime.getTime());
                CommonVariables.CurrentGlobalLog
                        .info("total execution time in Mins:" + String.valueOf(totalExecutionTime));
            }
            CommonVariables.ScenariosHighLevelLog.add("TC Passed-" + CommonVariables.PassTCCount.get() + ":: TC Failed-" + CommonVariables.FailTCCount.get() + ":: TC Skipped-" + CommonVariables.SkipTCCount.get());
            CommonVariables.CurrentGlobalLog.info("total Failed Test Case(s):" + context.getFailedTests().size());
            CommonVariables.CurrentGlobalLog.info("total Passed Test Case(s):" + context.getPassedTests().size());
            CommonVariables.CurrentGlobalLog.info("total Skipped Test Case(s):" + context.getSkippedTests().size());
            System.setProperty("selenium.tests.failCount", String.valueOf(context.getFailedTests().size()));
            System.setProperty("selenium.tests.passCount", String.valueOf(context.getPassedTests().size()));
            System.setProperty("selenium.tests.SkipCount", String.valueOf(context.getSkippedTests().size()));
        }
        if (context.getFailedTests().size() > 0 || context.getSkippedTests().size() > 0) {
            CommonVariables.ScenariosHighLevelLog.add("******************* Need to mark Build Failed: *************** With Exit Code:-" + context.getFailedTests().size() + context.getSkippedTests().size());
            int exitCode = context.getFailedTests().size() + context.getSkippedTests().size();
            System.out.println("******************* BUILD FAILED: *************** With Exit Code:-" + exitCode);
            System.exit(exitCode);
        }
/*		SendEmail.sendEmailReport(emailFrom, emailPass, emailToAddress.split("//;"), "myDevice Selenium Test Report - " + timestamp,
				"<br>Need to implement</br>", "");*/
    }


    /**
     * Assert that there were no validation failures
     *
     * @param testStatus
     */
    public void assertAllValidations(TestStatus testStatus) {
        if (testStatus.getValidationResults() != null) {
            Assert.assertTrue(testStatus.isValid(), testStatus.getValidationResults().toString());
        } else {
            Assert.assertTrue(testStatus.isValid(), "");
        }
    }

    @Override
    public void onFinish(ITestContext context) {
        super.onFinish(context);

    }

    @Override
    public void onStart(ITestContext context) {
        super.onStart(context);
/*		if(TestNGStarterFinishListener.moduleNeedToRun.size()>0)
		context.getCurrentXmlTest().setIncludedGroups(TestNGStarterFinishListener.moduleNeedToRun);
		if(TestNGStarterFinishListener.moduleNoNeedToRun.size()>0)
		context.getCurrentXmlTest().setExcludedGroups(TestNGStarterFinishListener.moduleNoNeedToRun);
		context.getCurrentXmlTest().setParallel("classes"); */
        context.getCurrentXmlTest().setThreadCount(TestNGStarterFinishListener.threadCount);
        context.getCurrentXmlTest().setPreserveOrder("false");
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        // TODO Auto-generated method stub

    }

    /**
     * Runs before every test.
     */
    @Override
    public void onTestStart(ITestResult result) {
//		super.onTestStart(result);
//		result.setAttribute(CommonVariables.TEST_STATUS_KEY, CommonVariables.testStatus.get());
        // Automatically create a new TestStatus object and attach it to the
        // test results
        result.setAttribute(CommonVariables.TEST_STATUS_KEY, testStatus.get());
    }

    /**
     * Runs when a test succeeds.
     */
    @Override
    public void onTestSuccess(ITestResult result) {
        super.onTestSuccess(result);
        if (CommonVariables.CurrentTestCaseLog.get() != null)
            CommonVariables.CurrentTestCaseLog.get().trace("Test success: " + result.getName());
    }

    /**
     * Runs when a test fails.
     */
    @Override
    public void onTestFailure(ITestResult result) {
        super.onTestFailure(result);
        if (CommonVariables.CurrentTestCaseLog.get() != null)
            CommonVariables.CurrentTestCaseLog.get().error("Test failure: " + result.getName());
        Throwable error = result.getThrowable();
        if (error != null) {
            CommonVariables.CurrentTestCaseLog.get().error(error.toString());
        }
    }

    /**
     * Runs when a test is skipped.
     */
    @Override
    public void onTestSkipped(ITestResult result) {
        super.onTestSkipped(result);
        if (CommonVariables.CurrentTestCaseLog.get() != null)
            CommonVariables.CurrentTestCaseLog.get().trace("Test skipped: " + result.getName());
    }
}
