package walmart.drone.delivery.automation;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class BasePage {

    public static int iTimeout;
    public WebDriverHelper _webDriverHelper;

    /**
     * Construct an instance of a BasePage with no WebDriver
     */
    public BasePage() {
    }

    /**
     * Construct an instance of a BasePage with a WebDriver.
     *
     * @param driver The selenium WebDriver instance for this page.
     * @throws ConfigurationException
     */
    public BasePage(WebDriver driver) {
        try {
            if (!TestContext.ArePropertiesSet) {
                CommonVariables.setTestContext();
            }
        } catch (Exception e) {
            System.out.println("Failed to load/set Config properties. Exception message: " + e.getLocalizedMessage());

        }
        iTimeout = CommonVariables.getTestContext().getIntProperty("globalTimeOut", 60);
        if (CommonVariables.getDriver() == null) {
            CommonVariables.setDriver(driver);
        }
        _webDriverHelper = CommonVariables.getCommonFunctionLib();
        try {
            AjaxElementLocatorFactory _ajaxLocatorFactory = new AjaxElementLocatorFactory(CommonVariables.getDriver(),
                    iTimeout);
            PageFactory.initElements(_ajaxLocatorFactory, this);
        } catch (TimeoutException timeoutEx) {
        }

    }

    /**
     * Retrieve the log4j logger used for this test.
     *
     * @return The configured log4j logger.
     */
    public static Logger getLogger() {
        if (CommonVariables.CurrentTestCaseLog.get() != null) {
            return CommonVariables.CurrentTestCaseLog.get();
        } else {
            return CommonVariables.CurrentTestClassLog.get();
        }
    }
    /**
     * Override this to customize the name of the page
     *
     * @return The name of the page.
     */
    public String getPageName() {
        return this.getClass().getSimpleName();
    }


}
