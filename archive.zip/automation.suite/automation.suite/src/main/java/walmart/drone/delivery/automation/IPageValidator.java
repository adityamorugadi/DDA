package walmart.drone.delivery.automation;

public interface IPageValidator<T extends BasePage> {
    public ValidationResults validate(T pageObject);
}
