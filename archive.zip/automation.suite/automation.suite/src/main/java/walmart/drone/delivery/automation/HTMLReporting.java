package walmart.drone.delivery.automation;

import org.apache.commons.io.IOUtils;
import org.testng.ITestContext;

import java.io.*;

public class HTMLReporting {
    static String webPageTitle = "Title";
    static String htmlreportFileName = "";
    static String logreportFileName = "";
    static String reportpath;

    static String highlevelhtmlreportFileName = "";
    static String highlevellogreportFileName = "";
    static String highlevelreportpath = "";

    static String TestCaseHeader = "Test Case Header Goes Here";
    static String ColumnHeader1 = "TimeStamp";
    static String ColumnHeader2 = "Log_Level";
    static String ColumnHeader3 = "Stacktrace";
    static String ColumnHeader4 = "Message";

    static String lastTCName = "NA";
    static int TCIterationCtr = 0;

    String logFilePath;

    //	public static void main(String args[]) throws IOException{
//		String Reportpath = "D:/Projects/myDevice/Automation/Java/New/logs/Results/2014_04_22_07_16_057/iPhone-Simulator/dummyTestCase/TestCases/";
//		String ReportName = "dummy_TC01";
//		HTMLReporting formatter = new HTMLReporting();
//		formatter.ConvertLogToHtml(Reportpath,ReportName);
//	}
    public boolean ConvertHighLevelLogToHtml(ITestContext context, String Reportpath, String ReportName) {
        highlevellogreportFileName = ReportName + ".log";
        highlevelhtmlreportFileName = ReportName + ".html";
        highlevelreportpath = Reportpath;
        CommonVariables.GlobalHTMLReportPath.set(highlevelreportpath + "/" + highlevelhtmlreportFileName);
        try {
            this.creatHighLevelReportFile(context);
            return true;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }
    }

    private void creatHighLevelReportFile(ITestContext context) throws IOException {
        File file = new File(highlevelreportpath + "/" + highlevelhtmlreportFileName);
        if (file.exists()) {
            System.out.println("Html file cannot be created. Exit!");
            return;
        }
        FileOutputStream reportOutputStream = new FileOutputStream(file);

        boolean flag = createNewHighLevelReportFile(context, reportOutputStream);
        if (!flag)
            return;
        readHighLevelLogFileAndCreateReport(highlevellogreportFileName, reportOutputStream);
    }

    private void readHighLevelLogFileAndCreateReport(String logFileName, FileOutputStream reportOutputStream) {
        try {
            File fileInput = new File(highlevelreportpath + "/" + logFileName);

            if (fileInput != null && !fileInput.exists()) {
                System.out.println("Path of Log File is not set.");
                return;
            }
            FileReader fileReader = new FileReader(fileInput);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                processLineHighLevel(line, reportOutputStream);
//				System.out.println(line);
            }
            reportOutputStream.write("</table></body></html>".getBytes());
            fileReader.close();
            reportOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void processLineHighLevel(String line, FileOutputStream outputStream) throws IOException {
        String parts[] = line.split("\\t");
        if (parts.length > 6) {
            if (!lastTCName.equals(parts[1])) {
                TCIterationCtr = 1;
            } else if (lastTCName.equals(parts[1])) {
                TCIterationCtr++;
            }
            String tableRow = "";
            //		System.out.println(parts.length);
            String color = ""; //74DF00
            if (parts[2].toUpperCase().trim().equals("PASS")) {
                color = "74DF00";
            } else if (parts[2].toUpperCase().trim().equals("FAIL")) {
                color = "FF0000";
            } else if (parts[2].toUpperCase().trim().equals("SKIP")) {
                color = "F7FE2E";
            } else if (parts[2].toUpperCase().trim().equals("DEBUG")) {
                color = "f2ff2f".toUpperCase();
            }
            try {
                //D:\Projects\myDevice\Automation\Java\New\logs\Results\2014_04_23_04_20_026_PM\iPhone-Simulator\dummyTestCase\TestCases\dummy_TC01.html
/*			String TestClassName = parts[0].toString();
			String TChtmlLogPath = CommonVariables.RootResultFolderPath + "/" + parts[0].trim() + "/TestCases/" + TestClassName + "-" + parts[1].trim()+ "_" + Thread.currentThread().getId() + ".html#section" + String.valueOf(TCIterationCtr);
			String DeviceName = CommonVariables.DeviceName;
			String tempStr = TChtmlLogPath.split(DeviceName)[1];
			TChtmlLogPath = "../" + DeviceName + tempStr;*/
                tableRow = String.format("<tr bgcolor=\"" + color + "\">"
                        + "<td style=\"width:200px;\">%s</td>"
	/*				+ "<td style=\"width:200px;\"><a href=\"" + TChtmlLogPath + "\">" +
					"%s" +
					"</a></td>"*/
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:500px;\">%s</td>"
                        + "<td style=\"width:200px;\">%s</td>"
                        + "<td style=\"width:200px;\">%s</td>"
                        + "<td style=\"width:200px;\">%s</td>"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "</tr>", parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6].replace("||", ", "));
                outputStream.write(tableRow.getBytes());
                outputStream.flush();
                lastTCName = parts[1];
            } catch (Exception ex) {
            }
            lastTCName = parts[1];
        }
    }

    private boolean createNewHighLevelReportFile(ITestContext context, FileOutputStream output) throws IOException {

        StringBuilder tableFormat = new StringBuilder();


        //Decide the Title of the Web Page
        tableFormat.append("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">"
                + "<html><title>" + "HighLevelLog" + "</title></head><body>");
        tableFormat.append("<TABLE style=\"BACKGROUND-COLOR: #e2e7de; FONT-SIZE: 12px\" " +
                "border=0 cellSpacing=1cellPadding=2 width=\"100%\"><TBODY><TR bgColor=#c1ccb8><TH " +
                "style=\"TEXT-ALIGN: left; FONT-SIZE: 20px; FONT-WEIGHT: bold\"colSpan=2>" +
                "Execution Summary : Walmart - Drone DeliveryRegression Suite" +
                "</TH></TR><TR bgColor=#a1ccb8><TD width=\"45%\" scope=row>" +
                "Passed TestCases" +
                "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                String.valueOf(context.getPassedTests().size()) +
                "</TD></TR><TR bgColor=#a1ccb8><TD>" +
                "Failed TestCases" +
                "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                String.valueOf(context.getFailedTests().size()) +
                "</TD></TR><TR bgColor=#a1ccb8><TD>" +
                "Skipped TestCases" +
                "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                String.valueOf(context.getSkippedTests().size()) +
                "</TD></TR><TR bgColor=#a1ccb8><TD>" +
                "ExecutionDate" +
                "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                String.valueOf(CommonVariables.ExecutionDate.get()) +
                "</TD></TR><TR bgColor=#a1ccb8><TD>" +
                "StartTime" +
                "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                String.valueOf(CommonVariables.ExecutionStartTime.get()) +
                "</TD></TR><TR bgColor=#a1ccb8><TD>" +
                "EndTime" +
                "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                String.valueOf(CommonVariables.ExecutionEndTime.get()) +
                "</TD></TR><TR bgColor=#a1ccb8><TD>" +
                "Device Name" +
                "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                String.valueOf(CommonVariables.DeviceName) +
                "</TD></TR><TR bgColor=#a1ccb8><TD>" +
                "Environment" +
                "</TD><TD style=\"PADDING-LEFT: 10px\"><B>" +
                String.valueOf(CommonVariables.getTestContext().getStringProperty("storeId", " ")) +
                "</B></TD></TR>"
                + "<TR bgColor=#a1ccb8><TD>" +
                "Machine Host Name" +
                "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                String.valueOf(CommonVariables.MachineHostName) +
                "</TD></TR>"
                + "<TR bgColor=#a1ccb8><TD>" +
                "Grid Node IP" +
                "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                String.valueOf(CommonVariables.getTestContext().getStringProperty("remoteSeleniumServer", null)) +
                "</TD></TR>"
        );


        //Header Content Goes Here
        tableFormat.append("<table border=\"1\">"
                + "<thead>"
                + "<tr bgColor=#c1ccb8>"
                + "<th style=\"width:100px;\">" + "Module/Test Class" + "</th>"
                + "<th style=\"width:100px;\">" + "Test Case" + "</th>"
                + "<th style=\"width:100px;\">" + "Status" + "</th>"
                + "<th style=\"width:100px;\">" + "TestCase Data Parameters" + "</th>"
                + "<th style=\"width:100px;\">" + "Start Time" + "</th>"
                + "<th style=\"width:100px;\">" + "End Time" + "</th>"
                + "<th style=\"width:100px;\">" + "TestCase Type" + "</th>"
                + "</tr></thead>");

        output.write(tableFormat.toString().getBytes());
        output.flush();
        return true;

    }

    public void ConvertLogToHtml(String Reportpath, String ReportName, Logtype type) {
        htmlreportFileName = ReportName + ".html";
        logreportFileName = ReportName + ".log";
        reportpath = Reportpath;
        TestCaseHeader = ReportName;
        try {
            this.creatReportFile(type);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    //**********************************************************************************************************************************//

    private void creatReportFile(Logtype type) throws IOException {
        logFilePath = reportpath;
        File file = new File(logFilePath + "/" + htmlreportFileName);
        FileOutputStream reportOutputStream = new FileOutputStream(file);
        System.out.println(type);
        switch (type) {
            case ClassLevel:
                if (createClassReportFile(reportOutputStream)) {
                    try {
                        File fileInput = new File(logFilePath + "/" + logreportFileName);

                        if (fileInput != null && !fileInput.exists()) {
                            System.out.println("Path of Log File is not set.");
                        } else {
                            FileReader fileReader = new FileReader(fileInput);
                            BufferedReader bufferedReader = new BufferedReader(fileReader);

                            String line;
                            while ((line = bufferedReader.readLine()) != null) {
                                processLine(line, reportOutputStream);
                                //					System.out.println(line);
                            }
                            reportOutputStream.write("</table></body></html>".getBytes());
                            fileReader.close();
                            reportOutputStream.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                break;
            case MethodLevel:
                if (createTestMethodReportFile(reportOutputStream)) {
                    readLogFileAndCreateReport(logreportFileName, reportOutputStream);
                }
                break;
            case HighLevel:
                break;
            default:
                break;
        }
    }

    private void readLogFileAndCreateReport(String logFileName, FileOutputStream reportOutputStream) {


        try {
            File fileInput = new File(logFilePath + "/" + logFileName);

            if (fileInput != null && !fileInput.exists()) {
                System.out.println("Path of Log File is not set.");
                return;
            }
            FileReader fileReader = new FileReader(fileInput);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                processLine(line, reportOutputStream);
//				System.out.println(line);
            }
            reportOutputStream.write("</table></body></html>".getBytes());
            fileReader.close();
            reportOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void processLine(String line, FileOutputStream outputStream) throws IOException {
        String parts[] = line.split("\\t");
        if (parts.length > 4) {
            String tableRow = "";
//		System.out.println(parts.length);
            if (parts[1].toUpperCase().trim().equals("ERROR")) {
                tableRow = String.format("<tr bgcolor=\"#FF0000\">"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:1000px;\">%s</td>"
                        + "</tr>", parts[0], parts[1], parts[2], parts[4].replace("\n", " "));
            } else if ((parts[1].toUpperCase().trim().equals("DEBUG")) && (!parts[4].toUpperCase().trim().contains("DATAPROVIDER ITERATION"))) {
                tableRow = String.format("<tr bgcolor=\"#F2FF2F\">"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:1000px;\">%s</td>"
                        + "</tr>", parts[0], parts[1], parts[2], parts[4].replace("\n", " "));
            } else if (((parts[1].toUpperCase().trim().equals("INFO")) || (parts[1].toUpperCase().trim().equals("DEBUG"))) && !(parts[4].toUpperCase().trim().contains("DATAPROVIDER ITERATION"))) {
                tableRow = String.format("<tr>"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:1000px;\">%s</td>"
                        + "</tr>", parts[0], parts[1], parts[2], parts[4].replace("\n", " "));
            } else if (parts[1].toUpperCase().trim().equals("PASS")) {
                tableRow = String.format("<tr bgcolor=\"#74DF00\">"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:1000px;\">%s</td>"
                        + "</tr>", parts[0], parts[1], parts[2], parts[4].replace("\n", " "));
            } else if (parts[1].toUpperCase().trim().equals("SCREENSHOT")) {
                String SS_Absolute_Path = parts[4];
                String tempStr = SS_Absolute_Path;
                if (SS_Absolute_Path.split("ScreenShots").length > 1)
                    tempStr = SS_Absolute_Path.split("ScreenShots")[1];
                String SS_Relative_Path = "../" + "ScreenShots" + tempStr;
                tableRow = String.format("<tr bgcolor=\"#FFA500\">"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:100px;\"><a href=\"" + SS_Relative_Path + "\">"
                        + "%s"
                        + "</a></td>"
                        + "<td style=\"width:100px;\">%s</td>"
                        + "<td style=\"width:1000px;\">%s</td>"
                        + "</tr>", parts[0], parts[1], parts[2], parts[4].replace("\n", " "));
            } else if (((parts[1].toUpperCase().trim().equals("INFO")) || (parts[1].toUpperCase().trim().equals("DEBUG"))) && (parts[4].toUpperCase().trim().contains("DATAPROVIDER ITERATION"))) {
                String strarr[] = parts[4].split(":");
                String ctr = strarr[1].trim();
                tableRow = String.format("<tr bgcolor=\"#BDBDBD\">"
                        + "<td "
                        + "<span style=\"font-weight:bold;height:50px\"colspan=\"4\"align=\"center\">"
                        + "<a name=\"section" + ctr + "\">"
                        + "%s"
//					"style=\"width:1000px;\"colspan=\"4\"align=\"center\"\"height:500px\"\"font-size: 22pt\">%s</td>"
                        + "</span></tr>", parts[4]);
            }

            outputStream.write(tableRow.getBytes());
            outputStream.flush();
        }
    }

    private boolean createTestMethodReportFile(FileOutputStream output) throws IOException {
        String TCName = "";
        String tempStr = TestCaseHeader.split("-")[1];
//		String tempStr2 = tempStr1.substring(0, TC_length-3);
        String Arr[] = tempStr.split("_");
        int arrLen = Arr.length;

        if (arrLen >= 3) {
            for (int i = 0; i < arrLen - 1; i++) {
                if (!TCName.equals("")) {
                    TCName = TCName + "_";
                }
                TCName = TCName + Arr[i];
            }
        } else {
            TCName = tempStr.split("_")[0];
        }
        String TestDescriptionKey = CommonVariables.CurrentTestClassName.get() + "-" + TCName;
        StringBuilder tableFormat = new StringBuilder();

        //Decide the Title of the Web Page,
        tableFormat.append("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">"
                + "<html><title>" + webPageTitle + "</title></head><body>");

        tableFormat.append("<font face=\'Tahoma'size=\'2\'><h1>Test Results  for: " + TCName + " </h1>");
        tableFormat.append("<font face=\'Tahoma'size=\'2\'><h1>Test Description: " + CommonVariables.TestMethodDescriptions.get(TestDescriptionKey) + " </h1>");

        //Header Content Goes Here
        tableFormat.append("<table border=\"1\">"
                + "<thead>"
                + "<tr bgColor=#c1ccb8>"
                + "<th style=\"width:100px;\">" + ColumnHeader1 + "</th>"
                + "<th style=\"width:100px;\">" + ColumnHeader2 + "</th>"
                + "<th style=\"width:100px;\">" + ColumnHeader3 + "</th>"
                + "<th style=\"width:100px;\">" + ColumnHeader4 + "</th>"
                + "</tr></thead>");

        output.write(tableFormat.toString().getBytes());
        output.flush();
        return true;

    }

    private boolean createClassReportFile(FileOutputStream output) throws IOException {
        try {
            String text = IOUtils.toString(new FileReader(new File(logFilePath + "/" + logreportFileName)));
            //System.out.println(text);
            int passCount = (text.length() - text.replace(":PASS:", "").length()) / 6;
            int failCount = (text.length() - text.replace(":FAIL:", "").length()) / 6;
            int skipCount = (text.length() - text.replace(":SKIP:", "").length()) / 6;
            String startTime = text.split("Start Time: ", 2)[1].trim().split("[\\r+\\n+\\s]", 2)[0];
            String endTime = text.split("End Time:", 2)[1].trim().split("[\\r+\\n+\\s]", 2)[0];
            StringBuilder tableFormat = new StringBuilder();
            //Decide the Title of the Web Page,
            tableFormat.append("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">"
                    + "<html><title>" + webPageTitle + "</title></head><body>");
            tableFormat.append("<font face=\'Tahoma'size=\'2\'><h1>Test Class Results  for: " + CommonVariables.CurrentTestClassName.get() + " </h1>");
//		tableFormat.append("<font face=\'Tahoma'size=\'2\'><h1>Test Description: " + CommonVariables.TestMethodDescriptions.get(TestDescriptionKey) + " </h1>");
            tableFormat.append("<TABLE style=\"BACKGROUND-COLOR: #e2e7de; FONT-SIZE: 12px\" " +
                            "border=0 cellSpacing=1cellPadding=2 width=\"100%\"><TBODY><TR bgColor=#c1ccb8><TH " +
                            "style=\"TEXT-ALIGN: left; FONT-SIZE: 20px; FONT-WEIGHT: bold\"colSpan=2>" +
                            "Execution Summary:" +
                            "</TH></TR><TR bgColor=#a1ccb8><TD width=\"45%\" scope=row>" +
                            "Passed TestCases" +
                            "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                            String.valueOf(passCount) +
                            "</TD></TR><TR bgColor=#a1ccb8><TD>" +
                            "Failed TestCases" +
                            "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                            String.valueOf(failCount) +
                            "</TD></TR><TR bgColor=#a1ccb8><TD>" +
                            "Skipped TestCases" +
                            "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                            String.valueOf(skipCount) +
/*				"</TD></TR><TR bgColor=#a1ccb8><TD>" +
				"ExecutionDate" +
				"</TD><TD style=\"PADDING-LEFT: 10px\">" +
				String.valueOf(CommonVariables.ExecutionDate.get()) +*/
                            "</TD></TR><TR bgColor=#a1ccb8><TD>" +
                            "StartTime" +
                            "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                            String.valueOf(startTime) +
                            "</TD></TR><TR bgColor=#a1ccb8><TD>" +
                            "EndTime" +
                            "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                            String.valueOf(endTime) +
                            "</TD></TR><TR bgColor=#a1ccb8><TD>" +
                            "Environment" +
                            "</TD><TD style=\"PADDING-LEFT: 10px\"><B>" +
                            String.valueOf(CommonVariables.environment) +
                            "</B></TD></TR>"
                            + "<TR bgColor=#a1ccb8><TD>" +
                            "Machine Host Name" +
                            "</TD><TD style=\"PADDING-LEFT: 10px\">" +
                            String.valueOf(CommonVariables.MachineHostName) +
                            "</TD></TR>"
/*				+ "<TR bgColor=#a1ccb8><TD>" +
				"Grid Node IP" +
				"</TD><TD style=\"PADDING-LEFT: 10px\">" +
				String.valueOf(CommonVariables.SeleniumGridNodeIP.get()) +
				"</TD></TR>"*/
            );
            //Header Content Goes Here
            tableFormat.append("<table border=\"1\">"
                    + "<thead>"
                    + "<tr bgColor=#c1ccb8>"
                    + "<th style=\"width:100px;\">" + ColumnHeader1 + "</th>"
                    + "<th style=\"width:100px;\">" + ColumnHeader2 + "</th>"
                    + "<th style=\"width:100px;\">" + ColumnHeader3 + "</th>"
                    + "<th style=\"width:100px;\">" + ColumnHeader4 + "</th>"
                    + "</tr></thead>");

            output.write(tableFormat.toString().getBytes());
            output.flush();
            return true;
        } catch (Exception ex) {
            return false;
        }

    }

    public static enum Logtype {
        HighLevel, ClassLevel, MethodLevel;
    }

}
