package walmart.drone.delivery.automation;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import org.apache.commons.configuration.ConfigurationException;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Set of helper methods for interacting with pages with a WebDriver.
 */
@SuppressWarnings("unchecked")
public class WebDriverHelper extends CommonJavaUtilsHelper {

    public static int driverStartfailureCount = 1;
    //protected static final Logger log = LogManager.getLogger("WebDriverHelper");
    WebDriver driver;
    WebDriverWait wait;
    AppiumDriverLocalService service;

    public WebDriverHelper(WebDriver driver) throws ConfigurationException {
        initPropertiesFile();
    }

    /**
     * method used to initialize Common properties.
     *
     * @throws ConfigurationException
     */
    private void initPropertiesFile() throws ConfigurationException {
        try {
            if (!TestContext.ArePropertiesSet) {
                CommonVariables.setTestContext();
            }
        } catch (Exception e) {
            CommonVariables.CurrentGlobalLog.error("Failed to load/set Config properties.");
            throw new ConfigurationException("Failed to load/set Config properties.", e);
        }
    }

    /**
     * Set driver
     *
     * @param driver
     */
    public void setDriver(WebDriver driver) {
        this.driver = driver;
    }

    public void closeDriver() {
        try {
            AcceptAlert();
            if (driver != null) {
                if (CommonVariables.DeviceName.toLowerCase().contains("chrome")) {
					/*				org.openqa.selenium.logging.LogEntries logEntries = null;
				try {
					logEntries = driver.manage().logs().get(LogType.BROWSER);
				} catch (Exception e) {}
				if (logEntries != null) {
					String filePath = CommonVariables.RootResultFolderPath + "/jsErrors.txt";
					for (org.openqa.selenium.logging.LogEntry entry : logEntries) {
						if ("SEVERE".equals(entry.getLevel().toString())) {
							writeAppendDataInFile(
									new Date(entry.getTimestamp()) + " " + entry.getLevel() + " " + entry.getMessage(),
									filePath);
						}
					}
				}*/
                } else {
                    ((IOSDriver<WebElement>) driver).removeApp("com.Walmart.stores.mywork.daily");
                    ((IOSDriver<WebElement>) driver).quit();
                }
            }
        } catch (Exception e) {
        }
        try {
            if (driver != null) {
                driver.quit();
                driver = null;
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e1) {
                }
            }
        } catch (Exception ex) {
        }
        try {
            CommonVariables.CommonDriver.get().quit();
            CommonVariables.CommonDriver.set(null);
        } catch (Exception e) {
            CommonVariables.CommonDriver.set(null);
        }

    }

    public boolean AcceptAlert() {
        try {
            org.openqa.selenium.Alert alert = driver.switchTo().alert();
            alert.accept();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

}
