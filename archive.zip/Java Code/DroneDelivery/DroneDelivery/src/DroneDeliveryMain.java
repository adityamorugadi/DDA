import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DroneDeliveryMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReader reader;
		List<DroneDelivery> deliveryList = new ArrayList<DroneDelivery>();
		List<DroneDelivery> deliveryOutputList = new ArrayList<DroneDelivery>();
		List<DroneDelivery> deliveryOutputListNPS = new ArrayList<DroneDelivery>();
		int finalDuration = 60000 * 11 * 60;
		
		int finalNPS = 0;

		try {
			PrintWriter writer = new PrintWriter("output.txt", "UTF-8");
			reader = new BufferedReader(new FileReader("input.txt"));
			String line = reader.readLine();
			while (line != null) {
				String[] inputLine = line.split(" ");

				if (inputLine.length == 3) {
					SimpleDateFormat sdf = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
					Date date = sdf.parse("70/01/01 " + inputLine[2]);

					Timestamp timeStamp = new Timestamp(date.getTime());
					DroneDelivery inputDroneDelivery = new DroneDelivery(inputLine[0], inputLine[1], timeStamp);
					deliveryList.add(inputDroneDelivery);
					System.out.println(inputDroneDelivery.toString());
				}
				line = reader.readLine();
			}
			reader.close();
			System.out.println("*********************************************");
			for (DroneDelivery temp : deliveryList) {

				String directionIndicator = temp.getDirectionIndicator();
				int duration = (DroneDeliveryMain.getDuration(directionIndicator) * 60000 * 2);
				int deliveryDuration = duration / 2;

				Timestamp timeStamp = new Timestamp(finalDuration);
				Timestamp timeStampNPS = new Timestamp(finalDuration + deliveryDuration);

				finalDuration = finalDuration + duration;
				DroneDelivery outputDelivery = new DroneDelivery(temp.getOrderIdentifier(), timeStamp);
				DroneDelivery outputDeliveryNPS = new DroneDelivery(temp.getOrderIdentifier(), timeStampNPS);

				deliveryOutputListNPS.add(outputDeliveryNPS);
				deliveryOutputList.add(outputDelivery);

				System.out.println("Pick up time is: " + outputDelivery.getList());
				System.out.println("Delivery time is: " + outputDeliveryNPS.getList());
				writer.println(outputDelivery.getList());
			}
			finalNPS = DroneDeliveryMain.getNPS(deliveryOutputListNPS, deliveryList);
			System.out.println("NPS " + finalNPS);
			writer.println(finalNPS);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	private static int getNPS(List<DroneDelivery> deliveryOutputList, List<DroneDelivery> deliveryList) {
		// TODO Auto-generated method stub
		int deliveryDifference = 0;
		int totalRecords = deliveryOutputList.size();
		int promoters = 0;
		int detractors = 0;
		int finalNPS = 0;
		for (DroneDelivery output : deliveryOutputList) {

			for (DroneDelivery input : deliveryList) {
				if (output.getOrderIdentifier().equalsIgnoreCase(input.getOrderIdentifier())) {
					deliveryDifference = (int) (output.getTimeStamp().getTime() - input.getTimeStamp().getTime());
					// System.out.println(deliveryDifference+":"+60000*60);
					if (deliveryDifference < (60000 * 60 * 2)) {
						promoters = promoters + 1;
					}
					if (deliveryDifference > (3 * 60000 * 60)) {
						detractors = detractors + 1;
					}
				}
			}
		}

		finalNPS = (promoters * 100 / totalRecords) - (detractors * 100 / totalRecords);
		// System.out.println(promoters+""+detractors+""+totalRecords);
		return finalNPS;
	}

	private static int getDuration(String directionIndicator) {
		int verticalNumberN = directionIndicator.indexOf("N");
		int verticalNumberS = directionIndicator.indexOf("S");
		int horizontalNumberW = directionIndicator.indexOf("W");
		int horizontalNumberE = directionIndicator.indexOf("E");
		int horizontalNumber = 0;
		int verticalNumber = 0;
		int horizontalDistance = 0;
		int verticalDistance = 0;
		if (verticalNumberN >= 0) {
			verticalNumber = verticalNumberN;
		} else if (verticalNumberS >= 0) {
			verticalNumber = verticalNumberS;
		} else {
			verticalNumber = 0;
		}
		if (horizontalNumberW > 0) {
			horizontalNumber = horizontalNumberW;
		} else if (horizontalNumberE > 0) {
			horizontalNumber = horizontalNumberE;
		} else {
			horizontalNumber = 0;
		}

		horizontalDistance = Integer.parseInt(directionIndicator.substring(horizontalNumber + 1));
		verticalDistance = Integer.parseInt(directionIndicator.substring(verticalNumber + 1, horizontalNumber));
		return (int) Math.hypot(horizontalDistance, verticalDistance);

	}

}
