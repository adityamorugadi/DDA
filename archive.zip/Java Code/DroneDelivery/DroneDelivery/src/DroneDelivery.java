import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.sql.Date;

public class DroneDelivery {
	private String orderIdentifier;
	private String directionIndicator;
	private Timestamp timeStamp;
	public String getOrderIdentifier() {
		return orderIdentifier;
	}
	public void setOrderIdentifier(String orderIdentifier) {
		this.orderIdentifier = orderIdentifier;
	}
	public String getDirectionIndicator() {
		return directionIndicator;
	}
	public void setDirectionIndicator(String directionIndicator) {
		this.directionIndicator = directionIndicator;
	}
	public Timestamp getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Timestamp timeStamp) {
		this.timeStamp = timeStamp;
	}
	public DroneDelivery(String orderIdentifier, String directionIndicator, Timestamp timeStamp) {
		super();
		this.orderIdentifier = orderIdentifier;
		this.directionIndicator = directionIndicator;
		this.timeStamp = timeStamp;
	}
	public DroneDelivery(String orderIdentifier, Timestamp timeStamp) {
		super(); 
		this.orderIdentifier = orderIdentifier;
		this.timeStamp = timeStamp;
	}
	
	public String getList() {
		Date date=new Date(timeStamp.getTime());
		DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");  
		String strDate = dateFormat.format(date);  
		return orderIdentifier +" "+  strDate ;
	}
	@Override
	public String toString() {
		return "DroneDelivery [orderIdentifier=" + orderIdentifier + ", directionIndicator=" + directionIndicator
				+ ", timeStamp=" + timeStamp + "]";
	}
	
}
