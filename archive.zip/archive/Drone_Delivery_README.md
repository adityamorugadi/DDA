#  Drone-Carried Delivery Application (DDA) Documentation

DDA application is used to manage drone-carried deliveries to customers in a small town. The town owns one drone, which is allowed to operate from 6 a.m. until 10 p.m. A drone launch scheduling program that maximizes the net promoter score (NPS) amongst drone-delivery customers. Net promoter score is defined as the percentage of promoters minus the percentage of detractors.

## Table of Contents

**[Assumptions](#assumptions)**

**[Limitations](#limitations)**

**[Automation Mechanisms](#AutomationMechanisms)**

## Assumptions

##### Provided DDA application
    . is a browser based application which is compatiable with all latest web browsers.
    . takes delivery instructions in a input file. Each line of input file represent an order. Each line includes an order identifier, followed by a space, the customer's grid coordinate, another space, and finally the order timestamp. The order identifier will have the format: WM####. The customer coordinate will have a North/South direction indicator (N or S) and a East/West indicator (E or W) -- for example: N5E10. The timestamp will have the format: HH:MM:SS.  
    . the orders in the input file will be sorted by order timestamp.
    . produces a file that contains one output line for each customer order. That line should indicate the order number and the drone's departure time. The last line in the output file should contain the estimated NPS score.
    . is not restrict to deliver orders in sequence in which they were received.
    . can process only one input file at a time. 
    . use a drone whose "ground speed" is exactly one horizontal or vertical grid block per minute. It is configuable property to test in lower environment.  
    . is launched in a town which is in a perfect grid shape, with a warehouse and drone-launch facility at the center. All deliveries originate at the warehouse and are carried by a drone to a customer location. 
	. travels at a speed of 1 mile per minute
	. assumes time to load and unload the delivery as 0.
	. has a separate application to calculate the maximum number of deliveries a drone can deliver during the day.

## Limitations

1. Application is not deployed in the test environment so we can't debug and execute automated test suite.

## Automation Mechanisms

1. Selenium is the best fit tool in this scenario considering an open source, big community support and work very well with browser based application and cross browser testing.
2. We will use TestNg as a testing framework. We'll migrate into Cucumber in future when we'll move towards TDD(Test-Driven Development) or BDD (Behavior-Driven Development) model.
3. Automation suite should be part of CICD pipeline to verify all existing features whenever any code checkin in long running branches.
4. CICD pipeline should mark the build failed if any automation script fails. Report will be generated and email to all stackholders.
5. We will use Java as a programming language to write automation test scripts.  